<template>
  <div class="overlay" @click.stop='clickOverlay' >
    <div class="popup" @click.stop v-obg-focus="{scene:scene, order:0}">
      <div class="pop-contents" >
        <obg-spinner :overlay='false' />
        <h2 class="title" >
          {{title}}
        </h2>
      </div>
    </div>
  </div>
</template>

<script>
import spinner from '../spinner'
import Events from '../../features/events'
export default {
  name: 'obg-loading-popup',
  components: {
    'obg-spinner': spinner
  },
  methods: {
    close () {
      this.$root.$destroy()
      this.$root.$el.parentNode.removeChild(this.$root.$el)
    }
  },
  data () {
    return {
      timeout: 5000,
      scene: 720,
      previousScene: 0
    }
  },
  props: {
    title: {
      type: String
    },
    clickOverlay: {
      type: Function,
      default: () => {
      }
    }
  },
  mounted () {
    const focusPos = this.$focus.getCurrentPosition()
    this.previousScene = focusPos.scene
    this.$focus.setScene(this.scene)
    this.$nextTick(() => {
      Events.$emit('popup:show', {
        type: 'popup',
        el: document.body.getElementsByClassName('popup')[0],
        prevFocusPosition: focusPos
      })
    })
    this.$root.closePopup = this.close
  },
  beforeDestroy () {
    this.$focus.setScene(this.previousScene)
    Events.$emit('popup:hide', {
      type: 'popup'
    })
  }
}
</script>

<style lang="scss" scoped >
/*
@import '../../styles/common/colors.variables';

.overlay{
    position:fixed;
    width:100%;
    height:100%;
    top:0;
    left:0;
    z-index:400;
    background-color:rgba(0, 0, 0, 0.8);
    display:flex;
    align-items:center;
    justify-content:center;
    color:white;

    .popup{
        flex:none;
        width:340px;
        min-height:66px;
        border:1px solid #737480;
        font-size:32px;
        flex-direction:column;
        display:flex;
        background:#2a2a2a;
        .pop-contents{
          padding-left:10px;
          padding-right:10px;
          text-align:center;
          display:flex;
          align-items:center;
          justify-content:center;
          .title{
              padding-left:10px;
              max-width:300px;
              font-size:32px; line-height:66px;
              text-align:center;
              overflow:hidden;
              text-overflow:ellipsis;
              display:block;
              white-space: nowrap;
              word-wrap: normal;
          }
        }
    }
}
*/
</style>
