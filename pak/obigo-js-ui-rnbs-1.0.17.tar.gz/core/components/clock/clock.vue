<template>
    <div class="obg-clock">
        <span class="obg-clock-now">{{now}}</span>
        <span class="obg-clock-meridiem">{{meridiem}}</span>
    </div>
</template>

<script>
export default{
  name: 'obg-clock',
  data () {
    return {
      meridiem: 'AM',
      now: '00:00'
    }
  },
  mounted () {
    this.updateDateTime()
    setInterval(this.updateDateTime, 6000)
  },
  methods: {
    updateDateTime () {
      const now = new Date()
      const hours = now.getHours() % 12 || 12
      let min = now.getMinutes()
      min = (parseInt(min, 10) >= 10 ? min : '0' + min)
      this.meridiem = (hours >= 12) ? 'PM' : 'AM'
      this.now = hours + ':' + min
    }
  }
}
</script>
<style lang="scss" >
    .obg-clock{
      font-size:37px;
      span{
        display:inline-block;
        &.obg-clock-meridiem{
          font-size:28px;
          margin-left:-6px;
        }
      }
    }
</style>
