<template>
  <button ref="origin"
          class="obg-combo-box-button"
          :disabled="disabled"
          :style="{width: width + 'px'}"
  >
    <label
      :style="{width: menuLabelWidth + 'px'}"
    >{{selectedItemLabel}}</label>
    <div
      class="arrow"
      :class="arrowDirection"
    />
    <obg-popover
      ref="popover"
      anchor="bottom left"
      self="top left"
      class="combo-box"
      :style="{ height: contextMenuHeight + 'px', width: width + 'px' }"
      @open="onOpen"
      @close="onClose"
    >
      <div class='scroll-container'>
        <div
          class="menu-item"
          v-for="(item, index) in options"
          :name="item.name"
          @click="onItemClick"
          :style="{height: itemHeight + 'px'}"
          :class="[{
            'selected': (selectedItemIndex === index)
          }]"
          :key="index"
        >
          <span
            class="item-content"
            :style="{lineHeight: itemHeight + 'px'}"
          >
            {{item.label}}
          </span>
        </div>
      </div>

    </obg-popover>
  </button>
</template>

<script>
  /**
   * @class combobox
   * @classdesc components/combobox
   * @param {array} options required
   * @param {boolean} [disabled]
   * @param {slot} [slot]
   * @param {number} [itemHeight=61]
   * @param {number} [focusZone=1]
   * @param {number} [value=-1]
   * @param {number} [width=260]
   *
   *
   * @example
   * <obg-combo-box
   *  :options="[{name: 'opt1', label: 'Option'}, {name: 'opt2', label: 'Advanced Setting'}, {name: 'opt3', label: 'Reset'}, {name: 'opt4', label: 'Help'}, {name: 'opt5', label: 'Smart Tutoriels'}]"
   * >
   * </obg-combo-box>
   */
  import popover from '../popover'
  import IScroll from '../../features/iscroll'

  const DEFAULT_WIDTH = 260
  const LABEL_MARGIN_WIDTH = 55
  const ARROW_DIRECTION_UP = 'up'
  const ARROW_DIRECTION_DOWN = 'down'
  const MIN_OPTION_LENGTH = 1
  const MAX_OPTION_LENGTH = 11

  export default {
    DEFAULT_WIDTH,
    LABEL_MARGIN_WIDTH,
    ARROW_DIRECTION_UP,
    ARROW_DIRECTION_DOWN,
    MIN_OPTION_LENGTH,
    MAX_OPTION_LENGTH,

    name: 'obg-combo-box',
    props: {
      disabled: {
        type: Boolean,
        default: false
      },
      itemHeight: {
        type: Number,
        default: 61
      },
      focusZone: {
        type: Number,
        default: 1
      },
      value: {
        type: Number,
        default: -1
      },
      width: {
        type: Number,
        default: DEFAULT_WIDTH
      },
      menuHeight: {
        type: Number,
        default: 0 // 257
      },
      options: {
        type: Array,
        required: true,
        validator (arr) {
          const len = arr.length

          if (len < MIN_OPTION_LENGTH) return false
          if (len > MAX_OPTION_LENGTH) return false

          for (let i = 0; i < len; i++) {
            const item = arr[i]
            if (typeof item !== 'object') return false
            if (!item.hasOwnProperty('name')) return false
            if (!item.hasOwnProperty('label')) return false
          }

          return true
        }
      }
    },
    data () {
      return {
        selectedItemIndex: 0,
        isOpen: false
      }
    },
    components: {
      'obg-popover': popover
    },
    computed: {
      contextMenuHeight () {
        if (this.menuHeight === 0) {
          let maxLenght = (this.options.length > 5) ? 5 : this.options.length
          return maxLenght * this.itemHeight + this.options.length - 3
        } else {
          return this.menuHeight
        }
      },
      selectedItemLabel () {
        if (this.options && this.options.length) {
          return this.options[this.selectedItemIndex].label
        }
        return ''
      },
      menuLabelWidth () {
        return this.width - LABEL_MARGIN_WIDTH
      },
      arrowDirection () {
        return this.isOpen ? 'up' : ARROW_DIRECTION_DOWN
      }
    },
    methods: {
      close () {
        this.$refs.popover.close()
        this.$emit('close')
      },
      open (event) {
        if (!this.disabled) {
          this.$refs.popover.open(event)
          this.$emit('open')
        }
      },
      onOpen () {
        this.isOpen = true
        this.makeScroll()
        this.$emit('open')
      },
      onClose () {
        this.isOpen = false
        this.$scroll.destroy()
        this.$scroll = undefined
        this.$emit('close')
      },
      onItemClick (e) {
        const name = e.currentTarget.getAttribute('name')
        this.selectedItemIndex = this.options.findIndex((item) => { return item.name === name })
        this.close()
      },
      makeScroll: function () {
        this.$scroll = new IScroll(this.$refs.popover.$el, {
          probeType: 2,
          bounce: true,
          mouseWheel: false,
          scrollbars: true,
          fadeScrollbars: false,
          interactiveScrollbars: false,
          click: true,
          disableMouse: false,
          disablePointer: true,
          snap: '.menu-item',
          preventDefaultException: {
            // default config, all form elements,
            // extended with a WebComponents Custom Element from the future
            tagName: /^(INPUT|TEXTAREA|BUTTON|SELECT|X-WIDGET)$/,
            // and allow any element that has an accessKey (because we can)
            accessKey: /.+/
          }
        })
        this.scrollToElement(this.selectedItemIndex)
      },
      scrollToElement: function (index) {
        this.$scroll.scrollToElement(this.$refs.popover.$el.children[0].children[index], 0)
      },
      onListItemClick () {
        if (this.$parent.$el.classList.contains('obg-list-item')) {
          this.open()
        }
      }
    },
    watch: {
      selectedItemIndex (val) {
        this.$emit('input', val)
      },
      value (val) {
        this.selectedItemIndex = val
      }
    },
    mounted () {
      this.target = this.$refs.popover.$el.parentNode
      this.target.addEventListener('contextmenu', this.open)
      if (this.value >= 0) {
        this.selectedItemIndex = this.value
      } else {
        this.selectedItemIndex = 0
      }
      this.$parent.$on('click', this.onListItemClick)
    },
    beforeDestroy: function () {
      if (this.$scroll) {
        this.$scroll.destroy()
        this.$scroll = undefined
      }
    }
  }
</script>
<style lang="scss" scoped>
/*
  @import '../../styles/common/colors.variables';
  */
  button.obg-combo-box-button {
    display: flex;
    width: 260px;
    height: 55px;
    color: #000000; /* color(black); */
    background-color: #ffffff; /* color(white); */
    font-size: 32px;
    outline: none;
    user-select: none;
    align-items: center;
    justify-content: center;
    & > label {
      width: 179px;
      padding: 0 10px 0 10px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      word-wrap: normal;
      line-height:55px;
    }
    & > div.arrow {
      height: 55px;
      width: 55px;
      background: #9f9f9f;
      box-shadow: inset 0 0 0 3px #ffffff; /* color(white); */
      &:before{
        position:absolute;
        content:"";
        width: 0;
        height: 0;
        border-style: solid;
        border-width: 14px 12px 0 12px;
        border-color: #000000 /* color(black) */  transparent transparent transparent;
        margin-left: -11px;
        margin-top: 22px;
      }
      &.up:before{
        border-width: 0px 12px 14px 12px;
        border-color: transparent transparent #030303 transparent;
      }
    }
    &:active{
      background-color: #b2d6fa;
      & > div.arrow {
        box-shadow: inset 0 0 0 3px #b2d6fa;
      }
    }
    &:disabled{
      opacity: 0.3;
      pointer-events: none;
    }
  }
  div.combo-box{
    width: 260px;
    height: 343px;
    overflow-y: hidden !important;
    & > div {
      & > div.menu-item {
        height:61px;
        color:#000000; /* color(black); */
        font-size:20px;
        text-indent:20px;
        display: flex;
        align-items: center;
        background: #ffffff; /* color(white); */
        padding: 0 10px 0 10px;
        border-bottom: 1px solid rgb(161,162,179); /* color(grey-3); */
        & > span {
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          word-wrap: normal;
        }
        &:last-child{
          border-bottom:none;
        }
        &:active{
          background: #b2d6fa;
        }
        &.obg-focus{
          box-shadow: inset 0 0 0px 4px #ffffff; /* color(white); */
          background: #cacaca;
        }
        &.selected{
          color:color(primary);
          box-shadow: inset 0 0 0px 3px #0078f0;  /* color(primary); */
        }
      }
    }


  }

</style>
