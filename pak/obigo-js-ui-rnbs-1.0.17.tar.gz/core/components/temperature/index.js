import temperature from './temperature'
export default temperature
