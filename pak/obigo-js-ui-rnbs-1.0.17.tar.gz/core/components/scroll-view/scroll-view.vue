<template>
  <div class='obg-scroll-view' >
    <div class='scroll-container' >
      <slot></slot>
      <div class='dummy-item' v-if="hideDummyItem == false && isEmpty == false" ></div>
    </div>
  </div>
</template>

<script>
import IScroll from '../../features/iscroll'
import spm from './scroll-position-manager'
import Events from '../../features/events'
/**
 * @class scrollview
 * @classdesc components/scroll-view
 * @param {boolean} [hideDummyitem=false]
 * @example
 * <obg-scroll-view>
 *  some content in here
 * </obg-scroll-view>
 */
export default {
  name: 'obg-scroll-view',
  props: {
    hideDummyItem: {
      type: Boolean,
      default: false
    },
    scrollKey: {
      type: String
    }
  },
  data () {
    return {
      isEmpty: true
    }
  },
  methods: {
    scrollEnd () {
      console.log('------')
      if (this.scrollKey !== undefined && this.$router) {
        spm.set(this.scrollKey + this.$router.history.current.fullPath, this.$scroll.y)
      }
      Events.$emit('list:scrollend')
    },
    scrollStart () {
      Events.$emit('list:scrollstart')
    },
    makeScroll: function () {
      if (this.$slots.default === undefined || this.$slots.default.length === 0) {
        this.isEmpty = true
        return
      }
      this.isEmpty = false
      this.$scroll = new IScroll(this.$el, {
        probeType: 2,
        bounce: true,
        mouseWheel: false,
        scrollbars: true,
        fadeScrollbars: true,
        interactiveScrollbars: false,
        click: true,
        disableMouse: false,
        disableTouch: false,
        disablePointer: true,
        dummyItem: !this.hideDummyItem,
        preventDefault: false
      })
      this.$scroll.on('scrollEnd', this.scrollEnd)
      this.$scroll.on('scrollStart', this.scrollStart)
      var lastPos = 0
      if (this.$router) { // 팝업의 컴포넌트로 list를 생서할 시 router는 전달되지 않으므로 라우터 검사 후 라우터 사용
        lastPos = spm.get(this.scrollKey + this.$router.history.current.fullPath)
      }
      if (this.$router && this.$router.isBack === true && lastPos !== undefined) {
        this.$scroll.scrollTo(0, lastPos, 0)    // scrollTo를 사용하면 iscroll의 pages속성을 업데이트하지않아 snap이 적용된 스크롤 동작이 정상적이지 않음. 그러나 scrollview는 snap을 사용하지 않음.
      }
    },
    refreshScroll: function () {
      if (this.$scroll) {
        if (this.$slots.default === undefined || this.$slots.default.length === 0) {
          this.isEmpty = true
          return
        } else {
          this.isEmpty = false
          this.$scroll.refresh()
        }
      } else {
        this.makeScroll()
      }
    }
  },
  updated: function () {
    this.refreshScroll()
  },
  mounted: function () {
    this.makeScroll()
  },
  beforeDestroy: function () {
    if (this.$scroll) {
      this.$scroll.destroy()
      this.$scroll = undefined
    }
  }

}
</script>
<style lang="scss" scoped >
  .obg-scroll-view{
    position:relative;
    overflow:hidden;
    color:white;
    .dummy-item{
      width:100%;
    }
  }
</style>

