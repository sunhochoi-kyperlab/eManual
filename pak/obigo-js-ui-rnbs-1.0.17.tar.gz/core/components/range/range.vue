<template>
  <div
    class="obg-range"
    :class="{ 'obg-range-disabled': disabled }"
    :style="{ 'width': rangeWidth + 'px'}"
    data-type="focus-control-able"
    @click.stop
  >
    <button
      class="obg-range-button down"
      :class="{'disabled': (min === model)}"
      ref="down"
      @click="valueDown"
    >
    </button>
    <div
      class="obg-slider-wrapper"
      :style="{width: (rangeWidth - 125) + 'px'}"
      ref="slider"
      @mousedown.stop="onPressSlider"
      @mouseup="onReleaseSlider"
      @touchstart.stop="onPressSlider"
      @touchend="onReleaseSlider"
    >
      <obg-slider
        class="slider-body"
        mode="range"
        :min="min"
        :max="max"
        :step="sliderStep"
        :sliderWidth="rangeWidth - 125"
        :barHeight="barHeight"
        :focus="focus"
        v-model="model"
        @input="onInput"
        :thumbScale="false"
        :thumbLabel="true"
        @dragstart="onDragStart"
        @dragend="onDragEnd"
      ></obg-slider>
    </div>
    <button
      class="obg-range-button up"
      :class="{'disabled': (max === model)}"
      ref="up"
      @click="valueUp"
    >
    </button>
  </div>
</template>
<script type="text/babel">
  /**
   * @class range
   * @classdesc components/range
   * @param {number} [min=0]
   * @param {number} [max=100]
   * @param {number} [step=1]
   * @param {number} [value=0]
   * @param {number} [barHeight=43]
   * @param {number} [rangeWidth=500]
   * @param {number} [stepPercent=1]
   * @param {boolean} [draggable=true]
   * @param {boolean} [disabled=false]
   * @param {event} [input]
   *
   * @example
   * <obg-range
   *  v-model="model"
   *  :min="0"
   *  :max="100"
   *  :step="10" @input="onInput"
   *  ></obg-range>
   */
  import longpress from '../../features/longPress'
  import slider from '../slider'
  import focusControlMixin from '../../mixins/focus-control'

  export default {
    name: 'obg-range',
    components: {
      'obg-slider': slider
    },
    mixins: [focusControlMixin],
    props: {
      min: {
        type: Number,
        default: 0
      },
      max: {
        type: Number,
        default: 100
      },
      step: {
        type: Number,
        default: 1
      },
      disabled: {
        type: Boolean,
        default: false
      },
      value: {
        type: Number,
        default: 0
      },
      barHeight: {
        type: Number,
        default: 43
      },
      rangeWidth: {
        type: Number,
        default: 460
      },
      stepPercent: {
        type: Number,
        default: 1
      }
    },
    data () {
      return {
        model: (this.value < this.min) ? this.min : this.value,
        focus: false,
        counter: 0,
        weight: 1,
        clickPosX: 0
      }
    },
    computed: {
      sliderStep () {
        return Math.ceil((this.max - this.min) / 100) * this.step
      }
    },
    mounted () {
      const up = this.$refs.up
      const down = this.$refs.down
      this.onepercent = Math.ceil((this.max - this.min) / 100)
      longpress(up, {
        counter: () => {
          this.valueUp()
          return !(this.value === this.max)
        },
        end: () => {
          this.onInput(this.model)
          this.reset()
        }
      })
      longpress(down, {
        counter: () => {
          this.valueDown()
          return !(this.value === this.min)
        },
        end: () => {
          this.onInput(this.model)
          this.reset()
        }
      })
      this.$on('focusout', () => {
        this.focus = false
      })
    },
    methods: {
      valueDown () {
        // this.model = this.model - this.onepercent * this.weight
        this.model = this.model - this.onepercent * this.step
        if (this.model < this.min) this.model = this.min
        this.$emit('input', this.model)
      },
      valueUp () {
        // this.model = this.model + this.onepercent * this.weight
        this.model = this.model + this.onepercent * this.step
        if (this.model > this.max) this.model = this.max
        this.$emit('input', this.model)
      },
      onInput (val) {
        this.$emit('input', val)
      },
      reset () {
        this.counter = 0
        this.onepercent = Math.ceil((this.max - this.min) / 100)
        this.weight = 1
      },
      addCount () { // TODO 가중치에 대해서는 논의 후 결정
        this.counter++
        if (this.counter % 8 === 0) {
          if (this.weight < 12) {
            this.weight += 4
          } else {
            this.weight = 10
          }
        }
      },
      onPressSlider (event) {
        this.clickPosX = (typeof event.pageX !== 'undefined') ? event.pageX : event.touches[0].pageX
      },
      onReleaseSlider (event) {
        if (event.changedTouches && event.changedTouches[0]) {
          event = event.changedTouches[0]
        }
        const pageX = event.pageX
        const target = (event.srcElement) ? event.srcElement : event.target
        if (Math.abs(this.clickPosX - pageX) < 5 && !target.classList.contains('obg-slider-thumb') && !target.classList.contains('obg-slider-current-value')) {
          const contentBox = this.$refs.slider.getBoundingClientRect()
          const deltaX = pageX - contentBox.left
          let newProgress = Math.floor(this.max * deltaX / contentBox.width)
          if (newProgress < this.min) {
            newProgress = this.min
          } else if (newProgress > this.max) {
            newProgress = this.max
          }
          newProgress = Math.round(newProgress / this.sliderStep) * this.sliderStep
          this.$emit('input', newProgress)
          this.model = newProgress
        }
        this.clickPosX = 0
      },
      onControlIn () {
        this.$el.querySelector('.obg-slider-thumb').classList.add('obg-focus')
        this.$el.addEventListener('mousedown', this.exitFocusMode)
        this.$el.addEventListener('touchstart', this.exitFocusMode)
        this.$refs.slider.addEventListener('mousedown', this.exitFocusMode)
        this.$refs.slider.addEventListener('touchstart', this.exitFocusMode)
      },
      onRotate ({mode}) {
        if (mode === this.hardkeyCodes.mode.HARDKEY_MODE_RIGHT) {
          this.valueUp()
        } else {
          this.valueDown()
        }
      },
      onRotateClick () {
        this.$el.querySelector('.obg-slider-thumb').classList.remove('obg-focus')
        this.$el.removeEventListener('mousedown', this.exitFocusMode)
        this.$el.removeEventListener('touchstart', this.exitFocusMode)
        this.$refs.slider.removeEventListener('mousedown', this.exitFocusMode)
        this.$refs.slider.removeEventListener('touchstart', this.exitFocusMode)
      },
      exitFocusMode () {
        this.$el.removeEventListener('mousedown', this.exitFocusMode)
        this.$el.removeEventListener('touchstart', this.exitFocusMode)
        this.$refs.slider.removeEventListener('mousedown', this.exitFocusMode)
        this.$refs.slider.removeEventListener('touchstart', this.exitFocusMode)
        this.exitFocusControlMode()
        this.$focus.exitFocusMode()
      },
      onDragStart (e) {
        this.$emit('dragstart', e)
      },
      onDragEnd (e) {
        this.$emit('dragend', e)
      }
    }
  }
</script>

<style lang="scss" scoped>
/*
  @import '../../styles/common/colors.variables';
  */


</style>
