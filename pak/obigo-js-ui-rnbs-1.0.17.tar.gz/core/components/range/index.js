import range from './range'
export default range
