<template>
  <div class="obg-carousel-container">
    <div class="obg-carousel-slider">
      <slot></slot>
    </div>
  </div>
</template>

<script>
  /**
   * @class cover-flow-portrait
   * @classdesc components/cover-flow-portrait
   * @param {number} [display=5] display count
   * @param {number} [perspective=35] degree of slide
   * @param {boolean} [loop=true]
   * @param {number} [animationSpeed=500] ms
   * @param {string} [dir=rtl] rtl | ltr
   * @param {number} [startIndex=0]
   * @param {number} [width=300]
   * @param {number} [height=200]
   * @param {function} [onSlideChange]
   * @param {function] [onLastSlide]
   * @param {slot} [slot] Cover-slide
   *
   * @example
   * <obg-cover-flow-portrait @input="onChange" :display=7 :value=3>
   *   <obg-cover-slide-portrait
   *    v-for="n in 11"
   *    :index="n-1"
   *    :label="'slide - ' + n"
   *    :content="n + ' - desc'"
   *   >
   *     Slide {{n}} Content
   *   </obg-cover-slide>
   * </obg-cover-flow>
   */
  import {parentMixin} from '../../mixins/cover-flow'
  export default {
    name: 'obg-cover-flow-portrait',
    mixins: [parentMixin],
    props: {
      perspective: {
        type: Number,
        default: 35
      },
      display: {
        type: Number,
        default: 7
      },
      width: {
        type: Number,
        default: 150
      },
      height: {
        type: Number,
        default: 140
      },
      space: {
        type: [Number, String],
        default: 'auto'
      },
      inverseScaling: {
        type: Number,
        default: 400
      }
    },
    data () {
      return {
        dragStartY: 0
      }
    },
    methods: {
      /**
       * Trigger actions when mouse is pressed
       * @param  {Object} e The event object
       */
      handleMousedown (e) {
        e.preventDefault()

        this.mousedown = true
        this.dragStartY = e.clientY
      },
      /**
       * Trigger actions when mouse is pressed and then moved (mouse drag)
       * @param  {Object} e The event object
       */
      handleMousemove (e) {
        if (!this.mousedown) {
          return
        }

        const eventPosY = e.clientY
        const deltaY = (this.dragStartY - eventPosY)

        this.dragOffset = deltaY

        if (this.dragOffset > this.minSwipeDistance) {
          this.handleMouseup()
          this.goNext()
        } else if (this.dragOffset < -this.minSwipeDistance) {
          this.handleMouseup()
          this.goPrev()
        }
      },
      /**
       * Trigger actions when mouse is released
       * @param  {Object} e The event object
       */
      handleMouseup () {
        this.mousedown = false
        this.dragOffset = 0
      },
      /**
       * Re-compute the number of slides and current slide
       */
      computeData () {
        this.total = this.getSlideCount()
        this.currentIndex = this.startIndex > this.total - 1 ? this.total - 1 : this.startIndex
        this.viewport = this.$el.clientHeight
      },
      setSize () {
        // this.$el.style.cssText += 'height:' + this.slideHeight
        // this.$el.childNodes[0].style.cssText += 'width:' + this.slideWidth + 'px;' + ' height:' + this.slideHeight + 'px'
      }
    },
    mounted () {
      if (this.value >= 0) {
        this.startIndex = this.value
      }
    }
  }
</script>

<style lang="scss" scoped>
  .obg-carousel-container {
    width: 100%;
    height: 100%;
    position: relative;
    z-index: 0;
    overflow: hidden;
    margin: 0 auto;
    box-sizing: border-box;
    & > .obg-carousel-slider {
      width: 100%;
      height: 100%;
      position: relative;
      margin: 0 auto;
      transform-style: preserve-3d;
      -webkit-perspective: 1000px;
      perspective: 1000px;
    }
  }
</style>
