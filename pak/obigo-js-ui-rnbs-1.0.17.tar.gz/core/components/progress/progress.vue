<template>
  <div class="obg-progress-bar">
    <slot name="start"></slot>
    <div class="obg-progress-content" :style="{ height: height + 'px', width: width + 'px' }">
      <div class="obg-progress-buffer" :style="{ width: bufferWidth + '%' }"></div>
      <div class="obg-progress-bar" :style="{ width: barWidth + '%' }"></div>
    </div>
    <slot name="end"></slot>
  </div>
</template>

<script>
/**
 * @class progress
 * @classdesc components/progress
 * @desc progress-bar with buffer
 * @param {slot} [slot] start label
 * @param {slot} [slot] end label
 * @param {number} [height=6]
 * @param {number} [width=600]
 * @param {number} [value=0] progress-bar width(%)
 * @param {number} [buffer=0] buffer-bar width(%)
 *
 * @example
 *  <obg-progress :value=0 :buffer=10 :height=15 :width=610 >
 *    <span slot='start'>start</span>
 *    <span slot='end'>end</span>
 *  </obg-progress>
 */
export default{
  name: 'obg-progress',
  props: {
    value: {
      type: Number,
      default: 0,
      validator: function (val) {
        return (val >= 0 && val <= 100)
      }
    },
    buffer: {
      type: Number,
      default: 0,
      validator: function (val) {
        return (val >= 0 && val <= 100)
      }
    },
    height: {
      type: Number
    },
    width: {
      type: Number
    }
  },
  data () {
    return {
      barWidth: 0,
      bufferWidth: 0
    }
  },
  mounted () {
    this.barWidth = this.value
    this.bufferWidth = this.buffer
  },
  watch: {
    value: function (val) {
      this.barWidth = val
    },
    buffer: function (val) {
      this.bufferWidth = val
    }
  }
}
</script>
<style lang="scss" >
/*
  @import '../../styles/common/colors.variables';
  */
  .obg-progress-bar{
    position: relative;
    display: flex;
    height: 30px;
    align-items: center;
    & > .obg-progress-content{
      position: relative;
      display: flex;
      background: #000000; /* color(black); */
      width: 600px;
      min-height: 6px;
      margin:7px;
      overflow: hidden;
      & > .obg-progress-bar {
        position: absolute;
        display: block;
        height: 100%;
        background: #0078f0; /* color(primary); */
        width: 0%;
      }
      & > .obg-progress-buffer{
        position: absolute;
        display: block;
        height: 100%;
        background: #222226; /* color(dark); */
        width: 0%;
      }
    }
    & *[slot="start"] {
      margin-right: 5px;
    }
    & *[slot="end"] {
      margin-left: 5px;
    }

  }
</style>
