import slider from './slider'
export default slider
