import footer from './footer'
export default footer
