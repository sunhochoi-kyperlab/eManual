<template>
    <svg viewBox="0 0 24 24">
        <path  d='M6 10c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm12 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm-6 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z' fill='#ffffff' />
    </svg>
</template>

<script>
    export default{
        props:['fill'],
        name:'icon-more',
    }
</script>
<style scoped>
    svg{
        display: inline-block;
        height: 40px;
        width: 40px;
        margin: 6px 7px 6px 6px;
    }
</style>

