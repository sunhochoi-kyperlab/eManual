<template>
  <div class='obg-dialog' v-if='dialogShow' ref="dialog">
    <div class='header' >
      <slot name='header'></slot>
    </div>
    <div class='content' >
      <slot name='content' ></slot>
    </div>
    <div class='footer' >
      <slot name='footer' >
      </slot>
      <div class='footer-btn' v-if='isDefaultFooter()' >
        <obg-button @click='close' class='close-btn' type='squareroundoutline' v-obg-focus="{scene: scene, isFocus: true}">
          <i class="obg-icon-close" slot="icon" ></i>
        </obg-button>
      </div>
    </div>
  </div>
</template>

<script>
/**
 * @class dialog
 * @classdesc components/dialog
 * @param {boolean} [show=false] - show/hide status
 * @param {string} [title='']
 * @param {slot} header - html for header slot
 * @param {slot} content - html for content slot
 * @param {slot} footer - html for footer slot<br/>if not define, default footer html that only one button to close is generated
 *
 * @example
 * <obg-dialog title='dialog title' >
 *  <div >dialog content</div>
 * </obg-dialog>
 */
import button from '../button'
import Events from '../../features/events'

export default {
  name: 'obg-dialog',
  components: {
    'obg-button': button
  },
  methods: {
    close () {
      this.$emit('close')
    },
    isDefaultFooter () {
      return this.$slots.footer === undefined
    }
  },
  data () {
    return {
      previousScene: 0
    }
  },
  watch: {
    dialogShow (val) {
      if (val) {
        let focusPos = this.$focus.getCurrentPosition()
        this.previousScene = focusPos.scene
        this.$focus.setScene(this.scene)
        this.$nextTick(() => {
          Events.$emit('popup:show', {
            type: 'dialog',
            el: this.$refs.dialog,
            prevFocusPosition: focusPos
          })
        })
      } else {
        this.$focus.setScene(this.previousScene)
        Events.$emit('popup:hide', {
          type: 'dialog'
        })
      }
    }
  },
  computed: {
    dialogShow: {
      get: function () {
        return this.show
      },
      set: function (newVal) {
        this.show = newVal
      }
    }
  },
  props: {
    title: {
      type: String,
      default: ''
    },
    show: {
      type: Boolean,
      default: false
    },
    scene: {
      default: 750,
      type: Number
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
