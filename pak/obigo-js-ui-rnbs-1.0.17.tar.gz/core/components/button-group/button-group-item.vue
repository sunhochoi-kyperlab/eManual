<template>
  <button
    class="obg-button-group-item"
    :class="[iconPosition, {
      'obg-button-group-current': currentIndex === $parent.currentIndex,
      'obg-button-group-icon': icon || $slots.icon,
      'disabled': disabled,
      'icon-only': !($slots.default)
    }]"
    @click.stop="onItemClick"
    @touchstart="onPressItem" @touchend="onReleaseItem"
  >
    <span
      class="obg-button-group-icon"
       v-if="icon || $slots.icon">
      <slot name="icon">
        <i v-if="icon" :class="'obg-icon-' + icon"></i>
      </slot>
    </span>
    <label class="obg-button-group-text"><slot></slot></label>
  </button>
</template>

<script>
/**
 * @class button-group-item
 * @classdesc components/button-group-item
 * @param {boolean} [disabled=false]
 * @param {string} [icon]
 * @param {string} [iconPosition=top] top | left
 * @param {boolean} [selected]
 * @param {slot} [slot] label
 * @param {slot} [icon] icon
 *
 * @example
 * <obg-button-group-item icon='more' iconPosition='top' @click ='onClick' selected>
 *   button1
 * </obg-button-group-item>
 */
import { childMixin } from '../../mixins/multi-items'

export default {
  name: 'obg-button-group-item',
  mixins: [childMixin],
  props: {
    icon: String,
    iconPosition: {
      type: String,
      default: 'top',
      validator (value) {
        return [
          'top',
          'left'
        ].indexOf(value) > -1
      }
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  methods: {
    onPressItem (e) {
      e.currentTarget.classList.add('active')
    },
    onReleaseItem (e) {
      e.currentTarget.classList.remove('active')
    }
  }
}
</script>

<style lang="scss">

</style>
