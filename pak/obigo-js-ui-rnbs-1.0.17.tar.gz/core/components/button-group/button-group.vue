<template>
  <div
    class="obg-button-group"
    :class="[{
      'is-animated': animated,
      'disabled': disabled
    }]"
    :style="{ width: buttonGroupWidth + 'px' }"
    v-obg-touch-swipe="swipeHandler"
  >
    <div
      class="slide-factor"
      v-if="animated"
      @touchstart="onPressItem" @touchend="onReleaseItem"
    />
    <slot></slot>
  </div>
</template>

<script>
/**
 * @class button-group
 * @classdesc components/button-group
 * @param {boolean} [animated=true]
 * @param {boolean} [disabled=false]
 * @param {slot} [slot] button-group-item
 * @example
 * <obg-button-group v-model="btnGroup" animated=true value=val >
 *    <obg-button-group-item>A</obg-button-group-item>
 *    <obg-button-group-item selected>B</obg-button-group-item>
 *    <obg-button-group-item>C</obg-button-group-item>
 * </obg-button-group>
 */
import { parentMixin } from '../../mixins/multi-items'

export default {
  name: 'obg-button-group',
  mixins: [parentMixin],
  data () {
    return {
    }
  },
  computed: {
    buttonGroupWidth: function () {
      var filtered = this.$slots.default.filter(function (item) { return (item.tag) })
      return filtered.length * 157.5
    }
  },
  props: {
    animated: {
      type: Boolean,
      default: true
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  watch: {
    currentIndex (val, oldVal) {
      if (this.animated) {
        const slidePosition = val * this.tweeningWidth + 6
        if (typeof oldVal === 'undefined' || oldVal < 0) {
          this.tween(0, slidePosition, this.$slideFactor, 0)
        } else {
          const startValue = oldVal * this.tweeningWidth
          this.tween(startValue, slidePosition, this.$slideFactor, 200)
        }
      }
    }
  },
  mounted () {
    this.clientWidth = this.$el.clientWidth
    this.tweeningWidth = this.clientWidth / this.number
    this.$slideFactor = this.$el.children[0]
    if (this.$children.length < 2 || this.$children.length > 5) {
      throw new Error('Count of Button-group-item is ' + this.$children.length + '\n Number of Button-group-item should be 2~5')
    }
    this.$parent.$on('jog-click', this.onListItemClick)
  },
  methods: {
    tween: function (startValue, endValue, el, duration) {
      const _style = el.style
      _style.transitionDuration = duration + 'ms'
      _style.webkitTransitionDuration = duration + 'ms'
      _style.transform = 'translateX(' + (endValue) + 'px) translateZ(0px)'
      _style.WebkitTransform = 'translateX(' + (endValue) + 'px) translateZ(0px)'
    },
    swipeHandler (obj) {
      let children = this.$children.slice()
      let index = this.currentIndex
      let targetIndex = 0
      let candidateArr
      if (obj.direction === 'left') {
        if (index === 0) return
        candidateArr = children.slice(0, index).reverse()
        targetIndex = this.checkAvailable(candidateArr)
        if (targetIndex < 0) return
        this.currentIndex = index - (targetIndex + 1)
      } else {
        if (index >= children.length - 1) return
        candidateArr = children.slice(index + 1)
        targetIndex = this.checkAvailable(candidateArr)
        if (targetIndex < 0) return
        this.currentIndex = index + targetIndex + 1
      }
    },
    checkAvailable (arr) {
      return arr.findIndex(item => {
        return !item.$el.classList.contains('disabled')
      })
    },
    onListItemClick () {
      if (this.disabled) return
      if (this.$parent.$el.classList.contains('obg-list-item')) {
        let children = this.$children.slice()
        let index = this.currentIndex
        let candidateArr = children.slice(index + 1)
        let targetIndex = this.checkAvailable(candidateArr)
        this.currentIndex = (targetIndex < 0) ? 0 : index + targetIndex + 1
      }
    },
    onPressItem (e) {
      e.currentTarget.classList.add('active')
    },
    onReleaseItem (e) {
      e.currentTarget.classList.remove('active')
    }
  }
}
</script>

<style lang="scss">

</style>
