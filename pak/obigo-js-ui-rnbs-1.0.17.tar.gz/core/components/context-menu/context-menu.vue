<template>
  <obg-button :icon="icon" ref="origin" :type="btnType" class="anchor">
    <slot name="icon"></slot>
    <slot></slot>
    <obg-popover
      ref="popover"
      :anchor="anchor"
      :self="self"
      class="context-menu"
      :style="{ height: contextMenuHeight + 'px' }"
      @open="showDimScreen"
      @close="hideDimScreen"
    >
      <div v-for="(item, index) in options" class='menu-item-wrapper' >
        <div
          :class="['menu-item',
            { 'disabled': item.disabled }
          ]"
          :name="item.name"
          @click.stop="onItemClick"
          @jog-click="onJogClick"
          v-obg-focus="{scene: scene, order: index}"
          :key="index"
        >
          <span class="item-content">
            {{item.label}}
          </span>
        </div>
      </div>
    </obg-popover>
    <div ref="dim" class="dim-context-menu" @click="onClickDim"></div>
    <button ref="closeButton" class="close-button-context-menu animate-scale" v-obg-focus="{scene: scene, order: (options.length === 0) ? -1 : options.length}">
      <i class="obg-icon-close" />
    </button>
  </obg-button>
</template>

<script>
  /**
   * @class context-menu
   * @classdesc components/context-menu
   * @param {boolean} [disable]
   * @param {slot} [slot]
   * @param {string} [btnType=round]
   * @param {string} [icon=more]
   * @param {number} [focusZone=99]
   * @param {array} options required
   * @param [scene=800]
   * @example
   * <obg-context-menu
   *  icon="more"
   *  :options="[{name: 'opt1', label: 'Option'}, {name: 'opt2', label: 'Advanced Setting'}, {name: 'opt3', label: 'Reset'}, {name: 'opt4', label: 'Help'}, {name: 'opt5', label: 'Smart Tutoriels'}]"
   * >
   * </obg-context-menu>
   */
  import popover from '../popover'
  import button from '../button'
  import Events from '../../features/events'
  import {triggerBodyClickEvent} from '../../utils/event'

  export default {
    props: {
      disable: Boolean,
      btnType: {
        type: String,
        default: 'round'
      },
      icon: {
        type: String,
        default: 'more'
      },
      focusZone: {
        type: Number,
        default: 99
      },
      scene: {
        default: 800,
        type: Number
      },
      anchor: {
        default: 'top middle',
        type: String
      },
      self: {
        default: 'bottom right',
        type: String
      },
      options: {
        type: Array,
        required: true,
        default: [],
        validator (arr) {
          if (arr.length < 1 || arr.length > 5) {
            return false
          }
          arr.forEach((item) => {
            if (!(item.hasOwnProperty('name') && item.hasOwnProperty('label'))) {
              throw new Error('options should be [{ name: xxxx, label: yyyy}, ...]')
            }
          })
          return true
        }
      }
    },
    components: {
      'obg-button': button,
      'obg-popover': popover
    },
    computed: {
      contextMenuHeight () {
        return this.options.length * 68 + this.options.length - 3
      }
    },
    watch: {
      options (val, oldVal) {
        this.$focus._focusMap.get(2).get(this.scene).delete(oldVal.length)
      }
    },
    updated () {
      this.$focus._addComponent(this.$refs.closeButton, {scene: this.scene, zone: 2, order: this.options.length})
    },
    methods: {
      close () {
        if (this.$refs.popover) this.$refs.popover.close()
        this.hideDimScreen()
      },
      __open (event) {
        if (!this.disable) {
          this.$refs.popover.open(event)
        }
      },
      onItemClick (e) {
        let name = e.currentTarget.getAttribute('name')
        this.$emit('input', name)
        triggerBodyClickEvent()
        this.close()
      },
      onJogClick () { // keep focus mode
        this.$focus._zoneFocusMode = true
        this.$focus._componentFocusMode = true
      },
      onClickDim () {
        this.$focus.exitFocusMode()
      },
      showDimScreen () {
        this.focusPos = this.$focus.getCurrentPosition()
        document.body.appendChild(this.$dim)
        document.body.appendChild(this.$closeButton)
        this.$dim.addEventListener('click', this.close)
        this.$closeButton.addEventListener('click', this.close)
        this.$emit('open')
        const focusPos = this.$focus.getCurrentPosition()
        this.previousScene = focusPos.scene
        this._Loop = this.$focus._Loop
        this.$focus.setScene(this.scene)
        this.$focus.setOptions({loop: true})
        this.$nextTick(() => {
          setTimeout(() => {
            Events.$emit('popup:show', {
              type: 'context',
              el: document.getElementsByClassName('obg-popover context-menu')[0],
              prevFocusPosition: this.focusPos
            })
          }, 200)
        })
      },
      hideDimScreen () {
        this.$dim.removeEventListener('click', this.close)
        this.$closeButton.removeEventListener('click', this.close)
        this.$emit('close')
        if (document.body.querySelector('.dim-context-menu')) document.body.removeChild(this.$dim)
        if (document.body.querySelector('.close-button-context-menu')) {
          document.body.removeChild(this.$closeButton)
          this.$focus.setScene(this.previousScene)
          this.$focus.setOptions({loop: this._Loop})
          this.$nextTick(() => {
            Events.$emit('popup:hide', {
              type: 'context'
            })
          })
        }
      }
    },
    mounted () {
      const originPos = this.$refs.origin.$el.getBoundingClientRect()

      this.target = this.$refs.popover.$el.parentNode
      this.target.addEventListener('contextmenu', this.__open)
      this.$dim = this.$refs.dim
      this.$closeButton = this.$refs.closeButton
      this.$closeButton.style.top = (originPos.top + originPos.height / 2 - this.$refs.closeButton.offsetHeight / 2) + 'px'
      this.$closeButton.style.left = (originPos.left + originPos.width / 2 - this.$refs.closeButton.offsetWidth / 2) + 'px'

      let $origin = this.$refs.origin.$el.getElementsByClassName('obg-button-text')[0]
      $origin.style.display = 'none'

      this.$nextTick(() => {
        this.$el.childNodes[2].removeChild(this.$dim)
        this.$el.childNodes[2].removeChild(this.$closeButton)
      })
    },
    beforeDestroy () {
      this.target.removeEventListener('contexmenu', this.handler)
    }
  }
</script>
<style lang="scss" scoped>
/*
  @import '../../styles/common/colors.variables';
  */

  .menu-item-wrapper{
    position:relative;
  }
  .animate-scale {
    animation: popover-scale .2s;
  }

  @keyframes popover-scale {
    0% {
      opacity: 0;
      transform: scale(0.7)
    }
    100% {
      opacity: 1;
      transform: scale(1)
    }
  }
</style>
