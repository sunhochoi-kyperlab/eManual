<template>
  <div class="obg-carousel-scroll">
    <div class="runway">

    </div>
  </div>
</template>

<script>
  export default {
    name: 'carousel-scroll',
    methods: {}
  }
</script>
<style lang='scss' scoped>
  .obg-carousel-scroll{

  }
</style>
