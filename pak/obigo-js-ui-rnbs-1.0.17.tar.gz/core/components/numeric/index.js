import numeric from './numeric'
export default numeric
