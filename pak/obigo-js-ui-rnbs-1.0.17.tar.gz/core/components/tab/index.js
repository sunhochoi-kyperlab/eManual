import tab from './tab.vue'
import tabItem from './tab-item.vue'

export {
  tab,
  tabItem
}
