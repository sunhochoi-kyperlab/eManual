<template>
  <a
    class="obg-tab-item"
    :class="[{
      'obg-tab-current': currentIndex === $parent.currentIndex,
      'obg-tab-icon': icon || $slots.icon,
      'disabled': disabled,
      'icon-only': !($slots.default),
      'obg-focus': isFocus
    }]"
    @click="onItemClick"
    @focusin="onFocusIn"
    @focusout="onFocusOut"
    ref="item"
  >
    <span
      class="obg-tab-icon"
      v-if="icon || $slots.icon">
      <slot name="icon">
        <i v-if="icon" :class="iconClass"></i>
      </slot>
    </span>
    <label class="obg-tab-text"><slot></slot></label>
  </a>
</template>

<script>
  /**
   * @class tab-item
   * @classdesc components/tab-item
   * @param {boolean} [disabled=false]
   * @param {string} [icon]
   * @param {boolean} [selected]
   * @param {slot} [slot] label
   * @param {slot} [icon] icon
   *
   * @example
   * <obg-tab-item
   *  icon='more'
   *  selected
   * >
   *   tab1
   * </obg-tab-item>
   */
  import { childMixin } from '../../mixins/multi-items'
  import Events from '../../features/events'

  export default {
    name: 'obg-tab-item',
    mixins: [childMixin],
    props: {
      icon: String,
      disabled: {
        type: Boolean,
        default: false
      }
    },
    computed: {
      iconClass: function () {
        return 'obg-icon-' + this.icon
      }
    },
    data () {
      return {
        itemWidth: 0,
        isFocus: false
      }
    },
    mounted () {
      this.$on('click', (e) => {
        if (this.currentSelected || this.disabled) return

        this.currentSelected = true
        this.$parent.currentIndex = this.currentIndex
        this.$emit('on-item-click', this.currentIndex)
        Events.$emit('tab:update', {
          currentIndex: this.currentIndex,
          isFocus: e.isFocus
        })
      })
      this.$on('focusin', this.onFocusIn)
      this.$on('focusout', this.onFocusOut)
      this.itemWidth = this.$el.offsetWidth
    },
    updated () {
      this.$nextTick(() => {
        this.itemWidth = this.$el.offsetWidth
        if (this.$refs.item) this.$refs.item.style.itemWidth = this.itemWidth / 2
      })
    },
    methods: {
      onFocusIn () {
        this.isFocus = true
      },
      onFocusOut () {
        this.isFocus = false
      }
    }
  }
</script>

<style lang="scss">
/*
  @import '../../styles/common/colors.variables';
  */
</style>
