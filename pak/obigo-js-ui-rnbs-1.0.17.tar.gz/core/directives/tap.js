/**
 *
 *  @module directives/tap
 *
 *  @example
 *  <obg-button v-tap="onTap" />
 *  <obg-button v-tap.ignoreThreshold.ignoreDelay="onTap"  />
 */
const threshold = 100
const name = 'tap'
const delay = 3000
const isTouchSupported = 'ontouchstart' in window
const startEvent = isTouchSupported ? 'touchstart' : 'mousedown'
const moveEvent = isTouchSupported ? 'touchmove' : 'mousemove'
const endEvent = isTouchSupported ? 'touchend' : 'mouseup'

export default {
  bind (el, {value = function () {}, modifiers}) {
    let ev
    let currentTarget
    let time
    let cb = typeof value === 'function' ? value : value.cb
    let ignoreThreshold = modifiers.ignoreThreshold
    let ignoreDelay = modifiers.ignoreDelay

    el.addEventListener(startEvent, e => {
      currentTarget = e.currentTarget
      ev = e.touches ? e.touches.length === 1 ? e.touches[0] : null : e
      if (ev) {
        time = +new Date()
        el.addEventListener(moveEvent, touchMove)
        el.addEventListener(endEvent, touchEnd)
      }
    })

    function touchMove (e) {
    }

    function touchEnd (e) {
      removeEventListener()

      let _ev = e.changedTouches && e.changedTouches.length > 0 ? e.changedTouches[0] : e

      if (!judgeEvent(ev, _ev, (ignoreThreshold) ? 9999 : threshold, currentTarget)) return

      if (modifiers.prevent) {
        e.preventDefault()
      }

      if (modifiers.stop) {
        e.stopPropagation()
      }

      let dur = +new Date() - time
      if (dur <= delay || ignoreDelay) {
        let tapEvent = createEvent(name, !modifiers.capture, { e })
        cb(tapEvent)
        el.dispatchEvent(tapEvent)
      }

      ev = null
      time = null
    }

    function removeEventListener () {
      el.removeEventListener(moveEvent, touchMove)
      el.removeEventListener(endEvent, touchEnd)
    }
  }
}

function judgeEvent (ev, _ev, threshold, currentTarget) {
  if (!ev || !_ev) return false

  const pos = currentTarget.getBoundingClientRect()
  const area = {
    startX: pos.left,
    endX: pos.left + pos.width,
    startY: pos.top,
    endY: pos.top + pos.height
  }

  const isStatic = Math.abs(ev.pageX - _ev.pageX) <= threshold && Math.abs(ev.pageY - _ev.pageY) <= threshold
  const isInArea = (area.startX < _ev.clientX && _ev.clientX < area.endX) && (area.startY < _ev.clientY && _ev.clientY < area.endY)

  return (ev.target === _ev.target && isStatic && isInArea)
}

function createEvent (name, bubbles, mixins = {}) {
  const tapEvent = document.createEvent('HTMLEvents')
  tapEvent.initEvent(name, bubbles, true)
  return Object.assign(tapEvent, mixins)
}
