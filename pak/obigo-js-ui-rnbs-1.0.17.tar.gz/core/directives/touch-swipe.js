import Utils from '../utils'

const isTouchSupported = 'ontouchstart' in window
const startEvent = isTouchSupported ? 'touchstart' : 'mousedown'
const moveEvent = isTouchSupported ? 'touchmove' : 'mousemove'
const endEvent = isTouchSupported ? 'touchend' : 'mouseup'

function getDirection (mod) {
  if (Object.keys(mod).length === 0) {
    return {
      left: true, right: true, up: true, down: true, horizontal: true, vertical: true
    }
  }

  let dir = {}

  ;['left', 'right', 'up', 'down', 'horizontal', 'vertical'].forEach(direction => {
    if (mod[direction]) {
      dir[direction] = true
    }
  })
  if (dir.horizontal) {
    dir.left = dir.right = true
  }
  if (dir.vertical) {
    dir.up = dir.down = true
  }
  if (dir.left || dir.right) {
    dir.horizontal = true
  }
  if (dir.up || dir.down) {
    dir.vertical = true
  }

  return dir
}

function updateClasses (el, dir) {
  el.classList.add('obg-touch')

  if (dir.horizontal && !dir.vertical) {
    el.classList.add('obg-touch-y')
    el.classList.remove('obg-touch-x')
  } else if (!dir.horizontal && dir.vertical) {
    el.classList.add('obg-touch-x')
    el.classList.remove('obg-touch-y')
  }
}

export default {
  bind (el, binding) {
    let ctx = {
      handler: binding.value,
      direction: getDirection(binding.modifiers),

      start (evt) {
        let position = Utils.event.position(evt)
        ctx.event = {
          x: position.left,
          y: position.top,
          time: new Date().getTime(),
          detected: false,
          prevent: ctx.direction.horizontal && ctx.direction.vertical
        }
        document.addEventListener(moveEvent, ctx.move)
        document.addEventListener(endEvent, ctx.end)
      },
      move (evt) {
        let position = Utils.event.position(evt)
        let distX = position.left - ctx.event.x
        let distY = position.top - ctx.event.y

        if (ctx.event.prevent) {
          evt.preventDefault()
          return
        }
        if (ctx.event.detected) {
          return
        }

        ctx.event.detected = true
        if (ctx.direction.horizontal && !ctx.direction.vertical) {
          if (Math.abs(distX) > Math.abs(distY)) {
            evt.preventDefault()
            ctx.event.prevent = true
          }
        } else {
          if (Math.abs(distX) < Math.abs(distY)) {
            evt.preventDefault()
            ctx.event.prevent = true
          }
        }
      },
      end (evt) {
        document.removeEventListener(moveEvent, ctx.move)
        document.removeEventListener(endEvent, ctx.end)

        let direction
        let position = Utils.event.position(evt)
        let distX = position.left - ctx.event.x
        let distY = position.top - ctx.event.y

        if (distX !== 0 || distY !== 0) {
          if (Math.abs(distX) >= Math.abs(distY)) {
            direction = distX < 0 ? 'left' : 'right'
          } else {
            direction = distY < 0 ? 'up' : 'down'
          }

          if (ctx.direction[direction]) {
            ctx.handler({
              evt,
              direction,
              duration: new Date().getTime() - ctx.event.time,
              distance: {
                x: Math.abs(distX),
                y: Math.abs(distY)
              }
            })
          }
        }
      }
    }

    Utils.store.add('touchswipe', el, ctx)
    updateClasses(el, ctx.direction)
    el.addEventListener(startEvent, ctx.start)
  },
  update (el, binding) {
    if (binding.oldValue !== binding.value) {
      let ctx = Utils.store.get('touchswipe', el)
      ctx.handler = binding.value
    }
  },
  unbind (el, binding) {
    let ctx = Utils.store.get('touchswipe', el)
    el.removeEventListener(startEvent, ctx.start)
    el.removeEventListener(moveEvent, ctx.move)
    el.removeEventListener(endEvent, ctx.end)
    Utils.store.remove('touchswipe', el)
  }
}
