
const colorTable = [
  {name: 'regular', rgb: 'rgb(230,240,255)'}, // #e6f0ff
  {name: 'basic', rgb: 'rgb(0,120,240)'}, // #0078f0
  {name: 'eco', rgb: 'rgb(120,220,0)'}, // #78dc00
  {name: 'sport', rgb: 'rgb(255,0,0)'}, // #ff0000
  {name: 'initiale', rgb: 'rgb(150,0,255)'}, // #9600ff
  {name: 'zen', rgb: 'rgb(0,220,255)'}, // #00dcff
  {name: 'race', rgb: 'rgb(255,200,0)'}, // #ffc800
  {name: 'mysense', rgb: 'rgb(255,90,0)'} // #ff5a00
]

import appManager from './appManager'
import { current as theme } from './theme'

let instance
class AmbientLight {
  constructor () {
    if (!instance) {
      instance = this
      this.appManager = appManager
      if (this.appManager) {
        this._currentMode = this._matchingColor(window.applicationFramework.util.getAmbientColor())
        this._bind()
        theme.set(this._currentMode)
      }
    }
    return instance
  }
  _matchingColor (rgbString) {
    const filtered = colorTable.filter((item) => {
      return item.rgb === rgbString
    })
    if (filtered.length === 0) {
      return colorTable[0].name
    }
    return (filtered[0]) ? filtered[0].name : 'basic'
  }
  _bind () {
    this.appManager.addEventListener('AmbientColorChanged', (e) => {
      this._currentMode = this._matchingColor(e.str)
      theme.set(this._currentMode)
    })
  }
  get () {
    return this._currentMode
  }
}

export function install (_Vue) {
  var ambient = new AmbientLight() // eslint-disable-line
  return instance
}
