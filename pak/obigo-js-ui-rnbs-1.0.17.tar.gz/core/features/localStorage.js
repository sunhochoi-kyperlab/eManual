/**
 * @module localStorage
 * @desc utility library of local storage.
 * <br/>use browser native local storage.
 *
 */
var appFrm = window.applicationFramework
var appName

if (appFrm) {
  var appMgr = appFrm.applicationManager
  var application = appMgr.getOwnerApplication(window.document)
  var wd = application.getDescriptor()
  appName = wd.name
} else {
  appName = 'dev'
}

var storage = {}
storage = {
  /**
   * @function get
   * @summary load data from local storage by key.<br/>
   * saved data can be accessed by it's application.
   * @param {string} key  - data key
   * @return {object}     - return data that matched key
   */
  get: function (key) {
    var strJson = window.localStorage.getItem(appName)
    if (typeof strJson !== 'undefined' && !!strJson && strJson !== null) {
      try {
        var obj = JSON.parse(strJson)

        if (typeof obj[key] !== 'undefined' && obj[key] !== null && obj[key] !== null) {
          return JSON.parse(obj[key])
        } else {
          return null
        }
      } catch (err) {
        return obj[key]
      }
    } else {
      return null
    }
  },

  /**
   * @function set
   * @summary save data to local storage <br/>
   * saved data can be accessed by it's application.
   * @param {string} key  - data key
   * @param {object} data - saved data
   */
  set: function (key, val) {
    var strJson = window.localStorage.getItem(appName)

    if (typeof strJson !== 'undefined' && !!strJson && strJson !== null) {
      try {
        var obj = JSON.parse(strJson)
      } catch (err) {

      }
    } else {
      obj = {}
    }

    if (typeof val === 'object') {
      val = JSON.stringify(val)
    }
    obj[key] = val

    try {
      window.localStorage.setItem(appName, JSON.stringify(obj))
    } catch (e) {
      if (e.code === 22) {
        console.log('error occurred while saving in local storage')
      }
    }
    // if fail throw QUOTA_EXCEEDED_ERR
    // code : 22
    // name : "QuotaExceededError"
  },

  /**
   * @function remove
   * @summary remove data from local storage
   * @param {string} key  - data key
   */
  remove: function (key) {
    var strJson = window.localStorage.getItem(appName)
    if (typeof strJson !== 'undefined' && !!strJson && strJson !== null) {
      try {
        var obj = JSON.parse(strJson)
        delete obj[key]

        window.localStorage.setItem(appName, JSON.stringify(obj))
      } catch (err) {
        return strJson
      }
    } else {
      return null
    }
  },

  /**
   * @function commonGet
   * @summary load common data from local storage<br/>
   * @param {string} key  - data key
   * @return {object}     - data
   */
  commonGet: function (key) {
    var strJson = window.localStorage.getItem(key)
    if (typeof strJson !== 'undefined' && !!strJson && strJson !== null) {
      try {
        var obj = JSON.parse(strJson)
        return obj
      } catch (err) {
        return strJson
      }
    } else {
      return null
    }
  },

  /**
   * @function commonSet
   * @summary save data to local storage<br/>
   * saved data by this method can be accessed all application.
   * @param {string} key  - data key
   * @param {object} val  - save data
   */
  commonSet: function (key, val) {
    if (typeof val === 'object') {
      val = JSON.stringify(val)
    }
    window.localStorage.setItem(key, val)
  },

  /**
   * @function commonRemove
   * @summary remove common data from local storage
   * @param {string} key  - data key
   */
  commonRemove: function (key) {
    if (window.localStorage[key]) {
      window.localStorage.removeItem(key)
    }
  },

  /**
   * @function clear
   * @summary clear all local storage data
   */
  clear: function () {
    if (window.localStorage.length !== 0) {
      window.localStorage.clear()
    }
  }
}

module.exports = storage
