import Utils from '../utils'
import Events from './events'

/**
 * @module theme
 * @desc theme function
 * @example
 * this.$theme.get()
 * this.$theme.set('basic')
 */
class Theme {
  constructor (theme) {
    this._currentTheme = theme
    Utils.dom.ready(() => {
      document.body.classList.add('obg-theme-' + this._currentTheme)
    })
  }
  /**
   * @function set
   * @param {string} [theme]
   * @summary set theme
   *
   */
  set (theme) {
    document.body.classList.remove('obg-theme-' + this._currentTheme)
    this._currentTheme = theme
    document.body.classList.add('obg-theme-' + theme)
    Events.$emit('theme:update', {
      name: theme
    })
  }
  /**
   * @function get
   * @summary get current theme
   * @return {string} theme name
   */
  get () {
    return this.currentTheme
  }

  /**
   * theme update event. emit by event bus
   *
   * @event theme:update
   * @type {object}
   * @property {string} name - theme name
   */
}

export var current = new Theme('basic')
