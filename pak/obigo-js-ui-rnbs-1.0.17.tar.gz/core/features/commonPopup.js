/*
 * 앱간 통신을 이용해 launcher 로부터 공통(crach, OOM) 메시지를 받는 라이브러리
 */
import popup from '../components/popup'
const AIC_NOTIFICATION = 'from-launcher-notification'
let instance
class CommonPopup {
  constructor () {
    if (!instance) {
      instance = this
      this.init()
    }
    return instance
  }
  init () {
    if (window.applicationFramework) {
      let appManager = window.applicationFramework.applicationManager
      let application = appManager.getOwnerApplication(window.document)
      application.registerMessageListener(AIC_NOTIFICATION)
      application.addEventListener('ApplicationMessage', (msg, origin) => {
        let filterName = (origin.indexOf('filter-name=') > -1) ? origin.split('filter-name=')[1] : ''
        if (filterName === AIC_NOTIFICATION && application === appManager.getTopmostApplication()) {
          msg = JSON.parse(msg)
          var shownPopup = popup.show({
            title: msg.title,
            content: msg.content,
            buttons: [{
              label: 'OK',
              onClick: () => {
                shownPopup.close()
              }
            }]
          })
        }
      }, false)
    }
  }
}
export default new CommonPopup()
/*
export function install (_Vue) {
  var commonPopup = new CommonPopup() // eslint-disable-line
  return instance
}
*/
