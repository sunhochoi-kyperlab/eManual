const isTouchSupported = 'ontouchstart' in window
const startEvent = isTouchSupported ? 'touchstart' : 'mousedown'
const moveEvent = isTouchSupported ? 'touchmove' : 'mousemove'
const endEvent = isTouchSupported ? 'touchend' : 'mouseup'

const parentMixin = {
  mounted () {
    this.computeData()
    this.setSize()
    this.$el.addEventListener(startEvent, this.handleMousedown)
    this.$el.addEventListener(endEvent, this.handleMouseup)
    this.$el.addEventListener(moveEvent, this.handleMousemove)
  },
  beforeDestroy () {
    this.$el.removeEventListener(startEvent, this.handleMousedown)
    this.$el.removeEventListener(endEvent, this.handleMouseup)
    this.$el.removeEventListener(moveEvent, this.handleMousemove)
  },
  props: {
    loop: {
      type: Boolean,
      default: true
    },
    animationSpeed: {
      type: Number,
      default: 500
    },
    display: {
      type: Number
    },
    dir: {
      type: String,
      default: 'rtl',
      validator (value) {
        return ['rtl', 'ltr'].indexOf(value) > -1
      }
    },
    value: {
      type: Number,
      default: -1
    },
    startIndex: {
      type: Number,
      default: 0
    },
    minSwipeDistance: {
      type: Number,
      default: 50
    },
    minSwipeTime: {
      type: Number,
      default: 100
    },
    onLastSlide: {
      type: Function,
      default: () => {}
    },
    onSlideChange: {
      type: Function,
      default: () => {}
    }
  },
  computed: {
    isLastSlide () {
      return this.currentIndex === this.total - 1
    },
    isFirstSlide () {
      return this.currentIndex === 0
    },
    isLastTwoSlide () {
      return this.currentIndex >= this.total - 2
    },
    isFirstTwoSlide () {
      return this.currentIndex <= 1
    },
    isNextPossible () {
      return !(!this.loop && this.isLastSlide)
    },
    isPrevPossible () {
      return !(!this.loop && this.isFirstSlide)
    },
    slideWidth () {
      const vw = this.viewport
      const sw = parseInt(this.width, 10)

      return vw < sw ? vw : sw
    },
    slideHeight () {
      const sw = parseInt(this.width, 10)
      const sh = parseInt(this.height, 10)
      const ar = this.calculateAspectRatio(sw, sh)

      return this.slideWidth / ar
    },
    visible () {
      const v = (this.display > this.total) ? this.total : this.display

      return v !== 2 ? (v % 2) ? v : v - 1 : v
    },
    hasHiddenSlides () {
      return this.total > this.visible
    },
    leftIndices () {
      const n = Math.floor(this.visible / 2) + 1
      const indices = []

      for (let m = 1; m < n; m++) {
        indices.push((this.dir === 'ltr')
          ? (this.currentIndex + m) % (this.total)
          : (this.currentIndex - m) % (this.total))
      }
      return indices
    },
    rightIndices () {
      const n = Math.floor(this.visible / 2) + 1
      const indices = []

      for (let m = 1; m < n; m++) {
        indices.push((this.dir === 'ltr')
          ? (this.currentIndex - m) % (this.total)
          : (this.currentIndex + m) % (this.total))
      }
      return indices
    },
    leftOutIndex () {
      const n = Math.floor(this.visible / 2) + 1

      if (this.dir === 'ltr') {
        return ((this.total - this.currentIndex - n) <= 0)
          ? (-parseInt(this.total - this.currentIndex - n))
          : (this.currentIndex + n)
      } else {
        return (this.currentIndex - n)
      }
    },
    rightOutIndex () {
      const n = Math.floor(this.visible / 2) + 1

      if (this.dir === 'ltr') {
        return (this.currentIndex - n)
      } else {
        return ((this.total - this.currentIndex - n) <= 0)
          ? (-parseInt(this.total - this.currentIndex - n, 10))
          : (this.currentIndex + n)
      }
    }
  },
  watch: {
    currentIndex (val, oldVal) {
      oldVal > -1 && this.$children[oldVal] && (this.$children[oldVal].currentSelected = false)
      val > -1 && (this.$children[val].currentSelected = true)
      this.previousIndex = oldVal
      this.$emit('input', val)
    },
    index (val) {
      this.currentIndex = val
    },
    value (val) {
      this.index = val
    }
  },
  data () {
    return {
      viewport: 0,
      currentIndex: this.index,
      total: 0,
      lock: false,
      dragOffset: 0,
      mousedown: false,
      index: -1,
      animationStartTime: 0,
      lastHandleTime: 0
    }
  },
  methods: {
    /**
     * Go to next slide
     */
    goNext () {
      if (this.isNextPossible) {
        this.isLastSlide ? this.goSlide(0) : this.goSlide(this.currentIndex + 1)
      }
    },
    /**
     * Go to previous slide
     */
    goPrev () {
      if (this.isPrevPossible) {
        this.isFirstSlide ? this.goSlide(this.total - 1) : this.goSlide(this.currentIndex - 1)
      }
    },
    /**
     * Go to slide
     * @param  {String} index of slide where to go
     */
    goSlide (index) {
      this.currentIndex = (index < 0 || index > this.total - 1) ? 0 : index
      this.lock = true

      if (this.isLastSlide) {
        this.onLastSlide(this.currentIndex)
      }

      setTimeout(() => this.animationEnd(), this.animationSpeed)
    },
    /**
     * Go to slide far slide
     */
    goFar (index) {
      let diff = (index === this.total - 1 && this.isFirstSlide) ? -1 : (index - this.currentIndex) // direction

      if (this.isLastSlide && index === 0) {
        diff = 1
      }

      if (this.display === 5) {
        if ((this.currentIndex === this.total - 2 && index === 0) || (this.currentIndex === this.total - 1 && index === 1)) {
          diff = 2
        }
        if ((this.currentIndex === 0 && index === this.total - 2) || (index === this.total - 1 && this.currentIndex === 1)) {
          diff = -2
        }
      }

      let timeBuff = 0
      let i = 0
      let diff2 = (diff < 0) ? -diff : diff // step count

      while (i < diff2) {
        i += 1
        const timeout = (diff2 === 1) ? 0 : (timeBuff)
        setTimeout(() => (diff < 0) ? this.goPrev() : this.goNext(), timeout)

        timeBuff += (this.animationSpeed / (diff2))
      }
    },
    /**
     * Trigger actions when animation ends
     */
    animationEnd () {
      this.lock = false
      this.onSlideChange(this.currentIndex)
    },
    /**
     * Get the number of slides
     * @return {Number} Number of slides
     */
    getSlideCount () {
      if (this.$slots.default !== undefined) {
        return this.$slots.default.filter((value) => {
          return value.tag !== void 0
        }).length
      }

      return 0
    },
    /**
     * Calculate slide with and keep defined aspect ratio
     * @return {Number} Aspect ratio number
     */
    calculateAspectRatio (width, height) {
      return Math.min(width / height)
    }
  }
}

const childMixin = {
  props: {
    index: {
      type: Number
    }
  },
  mounted () {
  },
  beforeDestroy () {
  },
  methods: {
    getSideIndex (array) {
      let index = -1

      array.forEach((pos, i) => {
        if (this.matchIndex(pos)) {
          index = i
        }
      })

      return index
    },
    matchIndex (index) {
      return (index >= 0) ? this.index === index : (this.parent.total + index) === this.index
    },
    goTo (click = true) {
      this.parent.goFar(this.index)
      if (click) {
        this.$emit('click', this.index)
      }
    }
  },
  watch: {

  },
  data () {
    return {
      parent: this.$parent,
      styles: {}
    }
  }
}

export {
  parentMixin,
  childMixin
}
