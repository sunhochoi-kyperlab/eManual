/**
 * Created by krinjadl on 2017-08-24.
 */
import Events from '../features/events'

const focusControlMixin = {
  methods: {
    onControlIn () {},
    _onControlIn () {
      this.onControlIn()
      this.focus = true
      this.bindCSW()
      window.addEventListener('click', this._onBodyClickListener)
      Events.$emit('focus:control-get', {'component': this})
    },
    onRotate (obj) {},
    _onRotate (obj) {
      this.onRotate(obj)
      this.$hardkey.sendRemainTick(0)
    },
    onRotateClick () {},
    _onRotateClick () {
      this.onRotateClick()
      this.exitFocusControlMode()
      this.$hardkey.sendRemainTick(0)
    },
    exitFocusControlMode () {
      this.removeFocusClass()

      this.unbindCSW()
      this.focus = false
      window.removeEventListener('click', this._onBodyClickListener)

      Events.$emit('focus:control-loss', {'component': this})
    },
    _onBodyClickListener () {
      this.exitFocusControlMode()
    },
    removeFocusClass () {
      const focusedElements = this.$el.querySelectorAll('.obg-focus')
      for (let i = 0; i < focusedElements.length; i++) {
        focusedElements[i].classList.remove('obg-focus')
      }
    },
    bindCSW () {
      this.$hardkey.addHardkeyListener(this.hardkeyCodes.code.HARDKEY_ROTARY_ROTATE, this._onRotate)
      this.$hardkey.addHardkeyListener(this.hardkeyCodes.code.HARDKEY_ROTARY_ENTER, this._onRotateClick)

      this.$hardkey.addHardkeyListener(this.hardkeyCodes.code.HARDKEY_ROTARY_LEFT, this.exitFocusControlMode)
      this.$hardkey.addHardkeyListener(this.hardkeyCodes.code.HARDKEY_ROTARY_RIGHT, this.exitFocusControlMode)
      this.$hardkey.addHardkeyListener(this.hardkeyCodes.code.HARDKEY_ROTARY_UP, this.exitFocusControlMode)
      this.$hardkey.addHardkeyListener(this.hardkeyCodes.code.HARDKEY_ROTARY_DOWN, this.exitFocusControlMode)
    },
    unbindCSW () {
      this.$hardkey.removeHardkeyListener(this.hardkeyCodes.code.HARDKEY_ROTARY_ROTATE, this._onRotate)
      this.$hardkey.removeHardkeyListener(this.hardkeyCodes.code.HARDKEY_ROTARY_ENTER, this._onRotateClick)

      this.$hardkey.removeHardkeyListener(this.hardkeyCodes.code.HARDKEY_ROTARY_LEFT, this.exitFocusControlMode)
      this.$hardkey.removeHardkeyListener(this.hardkeyCodes.code.HARDKEY_ROTARY_RIGHT, this.exitFocusControlMode)
      this.$hardkey.removeHardkeyListener(this.hardkeyCodes.code.HARDKEY_ROTARY_UP, this.exitFocusControlMode)
      this.$hardkey.removeHardkeyListener(this.hardkeyCodes.code.HARDKEY_ROTARY_DOWN, this.exitFocusControlMode)
    }
  },
  created () {
    this._onRotate = this._onRotate.bind(this)
    this._onRotateClick = this._onRotateClick.bind(this)
    this._onBodyClickListener = this._onBodyClickListener.bind(this)
  },
  mounted () {
    // this.$on('control:in', this._onControlIn)
    this.$on('jog-click', this._onControlIn)
    this.$el.addEventListener('jog-click', this._onControlIn)
  },
  activated () {
    // this.$on('control:in', this._onControlIn)
    this.$on('jog-click', this._onControlIn)
    this.$el.addEventListener('jog-click', this._onControlIn)
  },
  beforeDestroy () {
    // this.$off('control:in', this._onControlIn)
    this.$off('jog-click', this._onControlIn)
    this.$el.removeEventListener('jog-click', this._onControlIn)
  },
  deactivated () {
    // this.$off('control:in', this._onControlIn)
    this.$off('jog-click', this._onControlIn)
    this.$el.removeEventListener('jog-click', this._onControlIn)
  },
  data () {
    return {
      hardkeyCodes: this.$hardkey.getCodes(),
      focus: false
    }
  }
}
export default focusControlMixin
