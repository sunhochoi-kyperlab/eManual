/**
 * Created by krinjadl on 2017-08-23.
 */
import page from './page'

export default {
  page
}
