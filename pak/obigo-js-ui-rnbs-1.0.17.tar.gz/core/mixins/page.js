/**
 * @module mixin/page
 * @desc page mixin to create page component. if create page component, mix in it
 * @example
 * import page from 'obigo-js-ui/src/mixins/page'
 * export default{
 *   mixins: [page],
 *   data () {
 *     return { }
 *   },
 *   methods {
 *     // define methods
 *   },
 *   mounted () {
 *     // to do
 *   }
 * }
 *
 */
const pageMixin = {
  methods: {
    /**
     * @function setTitle
     * @desc to set page title.
     * @param {string} title - text to set title
     *
     */
    setTitle (title) {
      if (typeof title === 'string') {
        this._title = title
      } else if (this._title === this._appName) {
        let wd = this._application.getDescriptor()
        let lang = this._util.getLanguage()
        let name = wd.getWidgetName(lang)
        if (name) {
          this._title = name
          this._appName = name
        } else {
          this._title = '(No title)'
        }
      }
      try {
        this._application.setStatusBarTitle(this.$t(this._title))
      } catch (e) {
        console.log(e.message)
      }
    }
  },
  mounted () {
    if (window.applicationFramework) {
      this._application = window.applicationFramework.applicationManager.getOwnerApplication(window.document)
      this._util = window.applicationFramework.util
      this._application.addEventListener('ApplicationShown', this.setTitle, false)
      this._title = ''
      let wd = this._application.getDescriptor()
      let lang = this._util.getLanguage()

      let name = wd.getWidgetName(lang)
      if (name) {
        this._title = name
        this._appName = name
      } else {
        this._title = '(No title)'
      }
    }

    // if (this.$focus._componentFocusMode && this.autoFocus) {
    //   const lastPos = this.$focus.loadLastFocusPosition(this.scene)
    //
    //   this.$focus.setScene(this.scene)
    //
    //   if (lastPos && lastPos.zone === 3) {
    //     this.$focus._currentZone = 3
    //     this.$focus._currentOrder = lastPos.order
    //     this.$focus._setZoneFocusOn(3)
    //     this.$focus._setComponentFocusOn()
    //   } else {
    //     this.$focus.startFocusMode()
    //   }
    // }
  },
  // activated () {
  //   if (this.$focus._componentFocusMode && this.autoFocus) {
  //     const lastPos = this.$focus.loadLastFocusPosition(this.scene)
  //
  //     this.$focus.setScene(this.scene)
  //
  //     if (lastPos && lastPos.zone === 3) {
  //       this.$focus._currentZone = 3
  //       this.$focus._currentOrder = lastPos.order
  //       this.$focus._setZoneFocusOn(3)
  //       this.$focus._setComponentFocusOn()
  //     } else {
  //       this.$focus.startFocusMode()
  //     }
  //   }
  // },
  beforeDestroy () {
    if (window.applicationFramework) {
      this._application.removeEventListener('ApplicationShown', this.setTitle, false)
    }

    // this.$focus.storeLastFocusPosition(this.scene, this.$focus.getCurrentPosition())
  },
  deactivated () {
    // this.$focus.storeLastFocusPosition(this.scene, this.$focus.getCurrentPosition())
  },
  data () {
    return {
      scene: 0,
      _lastFocusOrder: -1,
      autoFocus: true
    }
  },
  watch: {
    scene (newScene, oldScene) {
      // this.$focus.setScene(newScene)
    }
  }
}
export default pageMixin
