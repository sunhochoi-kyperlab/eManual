module.exports = {
  createInstaller(...components) {
    const target = []
    components.forEach(component => {
      if (typeof component !== 'object') {
        return
      }

      if(!component.hasOwnProperty('name')) {
        return
      }

      target[component.name] = component
    })

    return function (Vue) {
      if (install.installed) return
      install.installed = true

      target.forEach((component, name) => {
        Vue.component(name, component)
      })
    }
  }
}
