class Request {
  constructor (opt) {
    this.xmlhttp = null
    this.opt = {
      url: null,
      type: 'GET',
      data: null,
      async: true,
      timeout: 5000,
      dataType: 'text',
      requestHeader: null
    }
    for (var p in opt) this.opt[p] = opt[p]
  }
  _encodeFormData (data) {
    var pairs = []
    var regexp = /%20/g
    for (var name in data) {
      if (data.hasOwnProperty(name)) {
        var val = data[name].toString()
        var pair = encodeURIComponent(name).replace(regexp, '+') + '=' + encodeURIComponent(val).replace(regexp, '+')
        pairs.push(pair)
      }
    }
    return pairs.join('&')
  }
  _parseXML (data) {
    var xml, tmp
    if (!data || typeof data !== 'string') {
      return null
    }

    try {
      tmp = new DOMParser()
      xml = tmp.parseFromString(data, 'text/xml')
    } catch (e) {
      xml = undefined
    }

    if (!xml || xml.getElementsByTagName('parsererror').length) {
      throw new Error('Invalid XML: ' + data)
    }
    return xml
  }
  _onLoad (evt) {
    var xmlObj, jsonObj
    var response = {}
    response.status = this.xmlhttp.status
    response.statusText = this.xmlhttp.statusText
    if (this.xmlhttp.status === 200 || this.xmlhttp.status === 0) {
      if (this.opt.dataType === 'json') {
        if (this.xmlhttp.responseText) {
          try {
            jsonObj = JSON.parse(this.xmlhttp.responseText)
          } catch (err) {
            response.data = 'json parseerror'
            this.reject(response)
            return
          }
          response.data = jsonObj
          this.resolve(response)
        } else {
          response.data = 'empty json'
          this.reject(response)
        }
      } else if (this.opt.dataType === 'xml') {
        if (this.xmlhttp.responseXML) {
          response.data = this.xmlhttp.responseXML
          this.resolve(response)
        } else if (this.xmlhttp.responseText) {
          try {
            xmlObj = this._parseXML(this.xmlhttp.responseText)
          } catch (err) {
            response.data = 'xml parseerror'
            this.reject(response)
            return
          }
          response.data = xmlObj
          this.resolve(response)
        } else {
          response.data = 'empty xml'
          this.reject(response)
        }
      } else {
        response.data = this.xmlhttp.responseText
        this.resolve(response)
      }
    // 500 internal error , Not found(server)
    } else if (this.xmlhttp.status !== 0) {
      response.data = 'error'
      this.reject(response)
    }
  }
  _onTimeout (evt) {
    var response = {}
    response.status = this.xmlhttp.status
    response.statusText = this.xmlhttp.statusText
    response.data = 'timeout'
    this.reject(response)
  }
  _onError (evt) {
    var response = {}
    response.status = this.xmlhttp.status
    response.statusText = this.xmlhttp.statusText
    if (typeof evt === 'string' && (evt === 'timeerror' || evt === 'nonetwork')) {
      response.data = evt
    } else {
      response.data = 'error'
    }
    this.reject(response)
  }
  _req () {
    return new Promise((resolve, reject) => {
      this.resolve = resolve
      this.reject = reject
      if (!this.opt.url) {
        reject({
          data: 'no url'
        })
      }
      this.xmlhttp = null
      this.xmlhttp = new XMLHttpRequest()

      this.xmlhttp.onload = this._onLoad.bind(this)
      this.xmlhttp.ontimeout = this._onTimeout.bind(this)
      this.xmlhttp.onerror = this._onError.bind(this)

      this.opt.type = this.opt.type.toUpperCase()
      if (this.opt.async) {
        this.xmlhttp.timeout = this.opt.timeout
      }
      if (this.opt.type === 'GET' && this.opt.data) {
        this.opt.data = this._encodeFormData(this.opt.data)
        this.opt.url = this.opt.url + '?' + this.opt.data
        this.opt.data = null
      }
      this.xmlhttp.open(this.opt.type, this.opt.url, this.opt.async)

      if (this.opt.type === 'POST' && !JSON.stringify(this.opt.requestHeader).match(/content-type/ig)) {
        this.xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8')
      }
      if (this.opt.requestHeader) {
        var headers = this.opt.requestHeader
        for (var key in headers) {
          if (headers.hasOwnProperty(key)) {
            this.xmlhttp.setRequestHeader(key, headers[key])
          }
        }
      }
      if (typeof this.opt.data === 'object') this.opt.data = this._encodeFormData(this.opt.data)

      this.xmlhttp.send(this.opt.data)
    })
  }
}

/**
 * @module ajax
 * @desc ajax library can request XMLHttp.
 * ajax library can connect to server by XMLHttpRequest object to get data from remote server.
 * it return promise. if success or fail to get data, returned promise object can handle it.
 *
 * @example
 * import ajax from 'obigo-js-ui/src/utils/ajax'
 * ajax.get({url: 'http://google.com'})
 * ajax.post({url: 'http://google.com', data: {a: 1, b: 2}})
 * ajax.delete({url: 'http://google.com'})
 * ajax.put({url: 'http://google.com'})
 * ajax.http({url: 'http://google.com', type: 'GET'})
 *
 */
class Ajax {
  /**
   * @function get
   * @summary http get request
   * @param {object} option - request object
   * @return {object} - promise
   *
   */
  get (opt) {
    opt.type = 'GET'
    return (new Request(opt))._req()
  }
  /**
   * @function post
   * @summary http post request
   * @param {object} option - request object
   * @return {object} - promise
   *
   */
  post (opt) {
    opt.type = 'POST'
    return (new Request(opt))._req()
  }
  /**
   * @function delete
   * @summary http delete request
   * @param {object} option - request object
   * @return {object} - promise
   *
   */
  delete (opt) {
    opt.type = 'DELETE'
    return (new Request(opt))._req()
  }
  /**
   * @function put
   * @summary http put request
   * @param {object} option - request object
   * @return {object} - promise
   *
   */
  put (opt) {
    opt.type = 'PUT'
    return (new Request(opt))._req()
  }
  /**
   * @function http
   * @summary http request
   * @param {object} option - request object
   * @return {object} - promise
   *
   */
  http (opt) {
    return (new Request(opt))._req()
  }
}

export default new Ajax()
